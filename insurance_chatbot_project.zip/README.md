# AI Powered Insurance Assistance Chatbot

## Overview

This chatbot assists users with insurance-related queries, including policy information, premium calculations, claim processes, and more.

## Setup Instructions

1. Install Rasa:
   ```
   pip install rasa
   ```

2. Initialize a Rasa project:
   ```
   rasa init --no-prompt
   ```

3. Replace your project files with the ones in this folder.

4. Train the model:
   ```
   rasa train
   ```

5. Run the action server:
   ```
   rasa run actions
   ```

6. Start the chatbot:
   ```
   rasa shell
   ```

## Features

- Provides insurance policy details
- Premium estimation
- Claim procedure information
- Lists required documents
- Customer support contact

## License

This project is for educational purposes.
